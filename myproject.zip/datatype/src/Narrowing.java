public class Narrowing {
    double d = 33.55;
    int i = (int) d;

    public static void main(String[] args) {
        System.out.println();
    }
}
