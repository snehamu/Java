public class Demo {
    void sum (){
        System.out.println("Hello");
    }

    public static void main(String[] args) {
        Demo d=new Demo();
        d.sum();
    }
}
