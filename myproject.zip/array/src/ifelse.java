public class ifelse {
    public static void main(String[] args) {
        int i = 5;
        if (i % 2 == 0) {
            System.out.println("Not Weird");
        } else {
            System.out.println("Weird");
        }
    }
}
