public class CalculatePerimeter {
    public static void main(String args[]) {
        Rectangle p = new Rectangle();
        p.setLength(5);
        p.setBreadth(7);
        System.out.print("Perimeter of Rectangle is:" +p.calculateperimeter());
    }
}
